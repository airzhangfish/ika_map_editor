package com.ikags.animemap.test;

import util.MapTools;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class MyViewMap extends View
{

  Bitmap myBmp;
  Paint paint = new Paint();
  int dog_x = 0;
  int dog_y = 0;

  public MyViewMap(Context context, AttributeSet attrs)
  {
    super(context, attrs);
    this.requestFocus();
    maptool=new MapTools("testmap_data.map","testmap_imgpak.bin",0,context);
    t.start();
  }
  static MapTools maptool=null;
  
  Thread t=new Thread(){
    
    public void run(){
      
      while(true){
      try
      {
        postInvalidate();
        Thread.sleep(60);
        
      }
      catch (InterruptedException e)
      {
        e.printStackTrace();
      }
      }
    }
    
  };
  
  

  public static String text = "moving text";

  protected void onDraw(Canvas canvas)
  {
    super.onDraw(canvas);
    
    
    try{
    canvas.drawColor(0xff000000);
    paint.setColor(0xffffffff);
    canvas.drawText("������ʾ:"+xss, 100, 100, paint);
 xss++;
 if(maptool!=null){
   maptool.StartedX=100;
   maptool.StartedY=100;
   maptool.paint(canvas.getWidth(), canvas.getHeight(), canvas); 
 }
    }catch(Exception ex){
      ex.printStackTrace();
    }
 
 
  }

  int xss = 0;

  public boolean onTouchEvent(MotionEvent event)
  {
    switch (event.getAction())
    {
      case MotionEvent.ACTION_DOWN:
        break;
      case MotionEvent.ACTION_MOVE:
        dog_x = ( int ) event.getX();
        dog_y = ( int ) event.getY();
        break;
      case MotionEvent.ACTION_UP:
        break;
    }
    invalidate();
    return true;
  }

  @Override
  protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec)
  {
    setMeasuredDimension(480, 640);
  }
}
